#!/bin/bash

[[ ! -f ./setenvVar ]] && echo "setenvVar file not found" && exit 1
source ./setenvVar
script_dir=$(cd "$(dirname "${BASH_SOURCE[0]}")" &>/dev/null && pwd -P)

[[ -d "$K8S_DIR" ]] && sudo rm -r "$K8S_DIR"
mkdir -p "$K8S_DIR"


command -v talosctl &> /dev/null || curl -sL https://talos.dev/install | sh &> /dev/null

talosctl gen secrets -o "$K8S_DIR"/secrets.yaml &> /dev/null
talosctl gen config --with-secrets "$K8S_DIR"/secrets.yaml bobo https://"$Endpoint":6443 -o "$K8S_DIR"
talosctl machineconfig patch "$K8S_DIR"/controlplane.yaml --patch @"$script_dir"/master.patch --output "$K8S_DIR"/controlplane_v2.yaml
talosctl machineconfig patch "$K8S_DIR"/worker.yaml --patch @"$script_dir"/worker.patch --output "$K8S_DIR"/worker_v2.yaml
talosctl --talosconfig="$K8S_DIR"/talosconfig  config endpoint $Endpoint
[ "$?" == "0" ] && echo "$Endpoint endpoint ok"

for s in $VM_list
do
  vn=$(echo $s | cut -d ':' -f 1)
  vid=$(echo $s | cut -d ':' -f 2)
  ip=$(echo $s | cut -d ':' -f 3)

  if echo "$ControlPlane_node_name" | grep -q "$vn"; then
    ## Init Talos Kubernetes
    if [[ "$VM_netid.$ip" == "$Endpoint" ]]; then
      talosctl apply-config --insecure --nodes $VM_netid.$ip --file "$K8S_DIR"/controlplane_v2.yaml
      [ "$?" == "0" ] && echo "Talos Control Plane ($VM_netid.$ip) ok"
      echo "waiting 120" && sleep 120

      talosctl  --nodes $VM_netid.$ip --talosconfig="$K8S_DIR"/talosconfig bootstrap
      [ "$?" == "0" ] && echo "K8S master ($VM_netid.$ip) ok"
      echo "waiting 360" && sleep 360

      curl -LO https://dl.k8s.io/release/$(curl -L -s https://dl.k8s.io/release/stable.txt)/bin/linux/amd64/kubectl &>/dev/null
      sudo chmod +x kubectl; sudo mv kubectl /usr/local/bin/
      rm ~/.kube/config 
      talosctl --nodes $VM_netid.$ip --talosconfig="$K8S_DIR"/talosconfig kubeconfig
      echo "kubectl ok"
    fi

    ## Join Controlplane node
    talosctl apply-config --insecure --nodes $VM_netid.$ip --file "$K8S_DIR"/controlplane_v2.yaml
    [ "$?" == "0" ] && echo "Talos Control Plane ($VM_netid.$ip) ok"
    echo "waiting 120" && sleep 120
  else    
    ## Join Worker node
    talosctl apply-config --insecure --nodes $VM_netid.$ip --file "$K8S_DIR"/worker_v2.yaml
    [ "$?" == "0" ] && echo "K8S worker ($VM_netid.$ip) ok"
  fi
done

kubectl get nodes
