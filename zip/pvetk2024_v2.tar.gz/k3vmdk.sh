#!/bin/bash

# function
## debug mode
Debug() {
  ### output log
  [[ -f /tmp/exec_k3vm.log ]] && sudo rm /tmp/exec_k3vm.log
  exec {BASH_XTRACEFD}>> /tmp/exec_k3vm.log
  set -x
  #set -o pipefail
}

Debug


## check env
echo "[Stage 1: check env]" && echo

[[ ! -f ./setenvVar ]] && echo "setenvVar file not found" && exit 1
source ./setenvVar

check_vars() {
  var_names=$(cat setenvVar | grep -v '#' | cut -d " " -f 2 | cut -d "=" -f 1 | tr -s "\n" " " | sed 's/[ \t]*$//g')
  for var_name in ${var_names[@]}
  do
    [ -z "${!var_name}" ] && echo "$var_name is unset." && exit 1
  done
  return 0
}

check_vars

command -v podman &> /dev/null || echo 'Please install podman'

### check ssh login to Proxmox node without password
ssh -o BatchMode=yes -o "StrictHostKeyChecking no" root@$NODE_1_IP '/bin/true' &> /dev/null
[[ "$?" != "0" ]] && echo "Must be configured to use ssh to login to the Proxmox node1 without a password." && exit 1


### check os
if cat /etc/os-release | grep -qi "Alpine"; then
  echo "Do not run this Bash Script on Alpine Linux, please run on Ubuntu Server 22.04 LTS" && exit 1
fi

echo "check env ok"

echo && echo "=====End of Stage 1=====" && echo

# delete VM
echo "[Stage 2: Stop and Delete VM]" && echo
for n in ${Proxmox_node[@]}
do 
  for d in $vmid
  do
    VM_STATUS=$(ssh root@"$NODE_1_IP" "pvesh get /nodes/$n/qemu/$d/status/current/ 2>> /tmp/exec_k3vm.log | grep -w 'status' | egrep -o 'running|stopped'")
    ssh root@"$NODE_1_IP" /bin/bash << EOF
      if [[ "$VM_STATUS" == "running" ]]; then
        pvesh create /nodes/$n/qemu/$d/status/stop 1> /dev/null &>> /tmp/exec_k3vm.log && echo "$d stoped"
        # [ "$?" == "0" ] && echo "$d running" && exit 1
        pvesh delete /nodes/$n/qemu/$d -skiplock=true &>> /tmp/exec_k3vm.log
        [ "$?" == "0" ] && echo "$d deleted"
      elif [[ "$VM_STATUS" == "stopped" ]]; then
        pvesh delete /nodes/$n/qemu/$d -skiplock=true &>> /tmp/exec_k3vm.log
        [ "$?" == "0" ] && echo "$d deleted"
      fi
EOF
  done
done

echo && echo "=====End of Stage 2=====" && echo

#exit

# Remaster Talos ISO and create raw disk
echo "[Stage 3: Remaster Talos ISO]" && echo
rm -r out
mkdir -p out
for s in $VM_list
do
  vn=$(echo $s | cut -d ':' -f 1)
  vid=$(echo $s | cut -d ':' -f 2)
  ip=$(echo $s | cut -d ':' -f 3)
   
  if ssh root@"$NODE_1_IP" "ls /root/out/talos-$vn.$ip.raw &> /dev/null"; then
    ssh root@"$NODE_1_IP" 'rm /root/out/talos-$vn.$ip.raw' &>> /tmp/exec_k3vm.log
  fi

  [[ -f "$PWD/out/metal-amd64.raw" ]] && sudo rm "$PWD/out/metal-amd64.raw" &> /dev/null
  sudo podman run --rm -t -v $PWD/out:/out  -v /dev:/dev --privileged ghcr.io/siderolabs/imager:"$Talos_OS_Version" \
  metal \
  --system-extension-image ghcr.io/siderolabs/qemu-guest-agent:"$Qemu_Agent_Version" \
  --extra-kernel-arg "ip=$VM_netid.$ip::$GATEWAY:255.255.0.0:$vn:eth0:off:172.20.0.254 net.ifnames=0" &>> /tmp/exec_k3vm.log

  sudo chown -R $(id -u):$(id -g) out &>> /tmp/exec_k3vm.log
  xz -v -d $PWD/out/metal-amd64.raw.xz &>> /tmp/exec_k3vm.log
  mv $PWD/out/metal-amd64.raw $PWD/out/talos-$vn.$ip.raw &>> /tmp/exec_k3vm.log
  scp $PWD/out/talos-$vn.$ip.raw root@$NODE_1_IP:/root/out/ &>> /tmp/exec_k3vm.log

  [ "$?" == "0" ] && echo "Create $PWD/out/talos-$vn.$ip.raw Disk ok"
done

echo && echo "=====End of Stage 3=====" && echo

# Create Talos VM
echo "[Stage 4: Create Talos VM]" && echo
for s in $VM_list
do
  vn=$(echo $s | cut -d ':' -f 1)
  vid=$(echo $s | cut -d ':' -f 2)
  ip=$(echo $s | cut -d ':' -f 3)

  if echo "$ControlPlane_node_name" | grep -q "$vn"; then
    ssh root@"$NODE_1_IP" /bin/bash << EOF &>> /tmp/exec_k3vm.log
      qm create "$vid"
      qm importdisk ${vid} /root/out/talos-$vn.$ip.raw $VMDK_Ceph_Pool

      qm set $vid \
      --name $vn \
      --cpu host --cores 2 --sockets 1 \
      --memory 4096 \
      --net0 bridge=vmbr1,virtio,firewall=1 \
      --scsihw virtio-scsi-single \
      --scsi0 $VMDK_Ceph_Pool:vm-"$vid"-disk-0,iothread=1 \
      --ostype l26 \
      --boot order=scsi0 \
      --agent enabled=1 &> /tmp/exec_k3vm.log
      qm resize ${vid} scsi0 +20G
EOF
    [[ "$?" == "0" ]] && echo "Create $vid success"
  else
    ssh root@"$NODE_1_IP" /bin/bash <<EOF &>> /tmp/exec_k3vm.log
      qm create "$vid"
      qm importdisk ${vid} /root/out/talos-$vn.$ip.raw $VMDK_Ceph_Pool

      qm set $vid \
      --name $vn \
      --cpu host --cores 2 --sockets 2 \
      --memory 8192 \
      --net0 bridge=vmbr1,virtio,firewall=1 \
      --scsihw virtio-scsi-single \
      --scsi0 $VMDK_Ceph_Pool:vm-"$vid"-disk-0,iothread=1 \
      --ostype l26 \
      --boot order=scsi0 \
      --agent enabled=1 &> /tmp/exec_k3vm.log
      qm resize ${vid} scsi0 +20G
EOF
    [[ "$?" == "0" ]] && echo "Create $vid success"
  fi
done 


### Migrate VMs to Specify node


ssh root@"$NODE_1_IP" /bin/bash -s "${Migrate_to_node[@]}" <<"EOF" | tee -a /tmp/exec_k3vm.log
  for i in "$@"
  do
    [[ "${i#*:}" == $NODE_1_IP ]] && contiune
    qm migrate "${i%:*}" "${i#*:}" &> /dev/null
    [[ "$?" == "0" ]] && echo "Migrate "${i%:*}" success"
    sleep 10
    pvesh create /nodes/"${i#*:}"/qemu/"${i%:*}"/status/start &> /dev/null
    [[ "$?" == "0" ]] && echo "VM "${i%:*}" Started"
  done
EOF

echo && echo "=====End of Stage 4=====" && echo

